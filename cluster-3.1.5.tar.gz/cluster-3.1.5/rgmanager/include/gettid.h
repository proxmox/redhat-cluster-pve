#ifndef __GETTID_H
#define __GETTID_H

pid_t gettid(void);

#endif

