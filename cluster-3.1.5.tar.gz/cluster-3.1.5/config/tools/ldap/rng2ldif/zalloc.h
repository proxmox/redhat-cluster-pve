#ifndef _ZALLOC_H
#define _ZALLOC_H

void *zalloc(size_t size);

#endif
