#ifndef _NAME_H
#define _NAME_H

char *normalize_name(const char *name);

#endif
