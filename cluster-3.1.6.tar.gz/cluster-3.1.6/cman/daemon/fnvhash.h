uint16_t fnv_hash(char *str);
