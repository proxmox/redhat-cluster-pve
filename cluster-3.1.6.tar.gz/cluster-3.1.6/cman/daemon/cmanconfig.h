int read_cman_nodes(struct corosync_api_v1 *api, unsigned int *config_version, int check_nodeids);
int read_cman_config(struct corosync_api_v1 *api, unsigned int *config_version);

