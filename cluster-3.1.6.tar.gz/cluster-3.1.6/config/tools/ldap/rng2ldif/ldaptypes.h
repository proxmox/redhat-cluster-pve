#ifndef _LDAPTYPES_H
#define _LDAPTYPES_H

void find_ldap_type_info(const char *name,
			 char **equality,
			 char **syntax);

#endif
